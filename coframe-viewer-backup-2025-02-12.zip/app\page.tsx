"use client";

import { useEffect, useState } from "react";
import CompatibilityPanel, {
  type Pair,
} from "@/components/CompatibilityPanel";
import FuturisticDonut, {
  type Segment,
} from "@/components/FuturisticDonut";
import { fetchBrands, type Brand } from "@/lib/coframeApi";

const TARGET_DURATION = 60;
const MAX_SLOT_SECONDS = 90;

const SLOT_COUNT = 5;

type GroupLevel = "ALTO" | "MEDIO" | "BAJO";

type GroupMatchResponse = {
  scoreGroup?: number | null;
  labelGroup?: string | null;
  pairs?: Pair[];
};

const getGroupLevel = (label?: string | null): GroupLevel | null => {
  if (!label) {
    return null;
  }
  const tone = label.toUpperCase();
  if (tone === "ALTO" || tone === "MEDIO" || tone === "BAJO") {
    return tone as GroupLevel;
  }
  return null;
};

export default function Home() {
  const [brands, setBrands] = useState<Brand[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedIds, setSelectedIds] = useState<string[]>(
    Array(SLOT_COUNT).fill(""),
  );
  const [groupScore, setGroupScore] = useState<number | null>(null);
  const [labelGroup, setLabelGroup] = useState<string | null>(null);
  const [pairs, setPairs] = useState<Pair[]>([]);
  const [loadingScore, setLoadingScore] = useState(false);
  const [errorScore, setErrorScore] = useState<string | null>(null);
  const [secondsBySlot, setSecondsBySlot] = useState<number[]>(
    Array(SLOT_COUNT).fill(0),
  );

  useEffect(() => {
    async function loadBrands() {
      try {
        const data = await fetchBrands();
        if (!data.length) {
          throw new Error("No se encontraron marcas en el endpoint.");
        }
        setBrands(data);
      } catch (err) {
        setError(
          err instanceof Error
            ? err.message
            : "No se pudieron cargar las marcas.",
        );
      } finally {
        setLoading(false);
      }
    }

    loadBrands();
  }, []);

  const handleChange = (slotIndex: number, value: string) => {
    setSelectedIds((prev) => {
      const copy = [...prev];
      copy[slotIndex] = value;
      return copy;
    });
  };

  const selectedNames = selectedIds
    .map((id) => brands.find((brand) => brand.id === id)?.name)
    .filter((name): name is string => Boolean(name));

  const selectedBrandIds = selectedIds.filter((id) => id !== "");
  const canCalculateGroup = selectedBrandIds.length >= 2;
  const totalSeconds = secondsBySlot.reduce((sum, value) => sum + value, 0);
  const segments: Segment[] = selectedIds
    .map((id, index) => {
      const seconds = secondsBySlot[index] || 0;
      if (!id || seconds <= 0) {
        return null;
      }
      const brand = brands.find((item) => item.id === id);
      if (!brand) {
        return null;
      }
      return {
        label: brand.name,
        value: seconds,
      };
    })
    .filter((segment): segment is Segment => Boolean(segment));

  const totalStatusClass =
    totalSeconds === TARGET_DURATION
      ? "text-emerald-300"
      : totalSeconds < TARGET_DURATION
        ? "text-amber-300"
        : "text-rose-300";

  const labelToneClass = (label?: string | null) => {
    const tone = getGroupLevel(label);
    if (tone === "ALTO") {
      return "bg-emerald-500/20 text-emerald-300";
    }
    if (tone === "MEDIO") {
      return "bg-amber-500/20 text-amber-300";
    }
    if (tone === "BAJO") {
      return "bg-rose-500/20 text-rose-300";
    }
    return "bg-white/10 text-white/80";
  };

  const activeGroupLevel = getGroupLevel(labelGroup);
  const pillLabel = activeGroupLevel ?? labelGroup;
  const scoreLevelClass =
    activeGroupLevel === "ALTO"
      ? "bg-emerald-500/10 border-emerald-400/60 shadow-[0_0_30px_rgba(34,197,94,0.7)] score-high-glow"
      : activeGroupLevel === "MEDIO"
        ? "bg-amber-500/10 border-amber-400/50 shadow-[0_0_20px_rgba(245,158,11,0.35)] score-medium-pulse"
        : activeGroupLevel === "BAJO"
          ? "bg-rose-500/10 border-rose-400/40 shadow-[0_0_18px_rgba(248,113,113,0.25)] score-low-breathe"
          : "shadow-[0_0_18px_rgba(15,15,15,0.65)]";

  const handleCalculateGroup = async () => {
    setLoadingScore(true);
    setErrorScore(null);
    setLabelGroup(null);
    setPairs([]);

    try {
      const response = await fetch("/api/group-match", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ brandIds: selectedBrandIds }),
      });

      const data: GroupMatchResponse = await response.json();

      if (!response.ok) {
        setGroupScore(null);
        setLabelGroup(null);
        setPairs([]);
        setErrorScore(
          (data as { message?: string; error?: string })?.message ??
            (data as { message?: string; error?: string })?.error ??
            "No se pudo calcular el grupo.",
        );
        return;
      }

      setGroupScore(data.scoreGroup ?? null);
      setLabelGroup(data.labelGroup ?? null);
      setPairs(Array.isArray(data.pairs) ? data.pairs : []);
      setErrorScore(null);
    } catch (err) {
      setGroupScore(null);
      setLabelGroup(null);
      setPairs([]);
      setErrorScore(
        err instanceof Error
          ? err.message
          : "Error desconocido al calcular el grupo.",
      );
    } finally {
      setLoadingScore(false);
    }
  };

  const handleSecondsAdjust = (slotIndex: number, delta: number) => {
    setSecondsBySlot((prev) => {
      const copy = [...prev];
      copy[slotIndex] = Math.max(
        0,
        Math.min(MAX_SLOT_SECONDS, copy[slotIndex] + delta),
      );
      return copy;
    });
  };

  if (loading) {
    return (
      <main className="min-h-screen bg-black p-6 text-white">
        <p className="text-sm text-white/80">Cargando marcas...</p>
      </main>
    );
  }

  if (error) {
    return (
      <main className="min-h-screen bg-black p-6 text-white">
        <p className="rounded border border-red-500/40 bg-red-500/10 p-4 text-red-200">
          {error}
        </p>
      </main>
    );
  }

  return (
    <div className="min-h-screen bg-black p-6 text-white">
      <main className="mx-auto max-w-5xl space-y-8">
        <div className="text-center space-y-1">
          <h1 className="text-2xl font-bold text-white">
            COFRAME – Análisis de Compatibilidad de Marcas
          </h1>
          <p className="text-sm text-white/70">
            Seleccioná hasta 5 marcas para explorar la estructura del grupo.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <div className="space-y-4 rounded-2xl border border-white/15 bg-white/5 p-4">
            {Array.from({ length: SLOT_COUNT }).map((_, index) => {
              const secondsValue = secondsBySlot[index];
              return (
                <div key={`slot-${index}`} className="space-y-3">
                  <label className="text-xs font-semibold uppercase tracking-wider text-white/80">
                    MARCA {index + 1}
                  </label>
                  <select
                    value={selectedIds[index]}
                    onChange={(event) =>
                      handleChange(index, event.target.value || "")
                    }
                    className="w-full rounded border border-white/20 bg-black/60 p-3 text-white shadow-inner focus:border-white focus:outline-none"
                  >
                    <option value="">Seleccionar marca...</option>
                    {brands.map((brand) => (
                      <option key={brand.id} value={brand.id}>
                        {brand.name}
                      </option>
                    ))}
                  </select>
                  <div className="flex items-center justify-between gap-2 rounded-2xl border border-white/10 bg-black/40 px-3 py-2">
                    <button
                      type="button"
                      aria-label="Restar segundos"
                      onClick={() => handleSecondsAdjust(index, -1)}
                      disabled={secondsValue <= 0}
                      className="inline-flex h-8 w-8 items-center justify-center rounded-full border border-white/20 bg-white/5 text-lg text-white/70 transition hover:bg-white/20 disabled:cursor-not-allowed disabled:opacity-40"
                    >
                      –
                    </button>
                    <span className="text-sm font-semibold text-white">
                      {secondsValue}s
                    </span>
                    <button
                      type="button"
                      aria-label="Sumar segundos"
                      onClick={() => handleSecondsAdjust(index, 1)}
                      disabled={secondsValue >= MAX_SLOT_SECONDS}
                      className="inline-flex h-8 w-8 items-center justify-center rounded-full border border-white/20 bg-white/5 text-lg text-white/70 transition hover:bg-white/20 disabled:cursor-not-allowed disabled:opacity-40"
                    >
                      +
                    </button>
                  </div>
                </div>
              );
            })}

            <div
              className={`flex items-center justify-between rounded-2xl border border-white/10 bg-black/40 px-4 py-3 text-sm font-semibold ${totalStatusClass}`}
            >
              <span>Total asignado</span>
              <span>
                {totalSeconds}s / {TARGET_DURATION}s
              </span>
            </div>

          </div>

          <div className="space-y-5 rounded-3xl border border-white/10 bg-gradient-to-b from-zinc-950/60 to-black/60 p-5">
            <button
              type="button"
              onClick={handleCalculateGroup}
              disabled={loadingScore || !canCalculateGroup}
              className="mx-auto flex h-16 w-full max-w-xl items-center justify-center rounded-full bg-gradient-to-r from-emerald-400 via-lime-400 to-emerald-500 text-white text-sm font-semibold uppercase tracking-[0.18em] shadow-[0_0_35px_rgba(34,197,94,0.55)] transition-transform duration-200 hover:scale-[1.01] hover:brightness-110 focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400 disabled:cursor-not-allowed disabled:opacity-60 disabled:hover:scale-100 disabled:hover:brightness-100 sm:text-base"
            >
              CALCULAR GRUPO
            </button>
            <div className="flex min-h-[160px] flex-col items-center justify-center gap-3 rounded-2xl border border-white/10 bg-black/40 px-6 py-6 text-center">
              {loadingScore && (
                <p className="text-sm font-semibold uppercase tracking-[0.2em] text-white/80">
                  Calculando...
                </p>
              )}
              {!loadingScore && errorScore && (
                <p className="text-sm text-amber-400">{errorScore}</p>
              )}
              {!loadingScore && !errorScore && groupScore !== null && (
                <div
                  className={`mx-auto mt-2 inline-flex w-full max-w-sm flex-col items-center gap-2 rounded-2xl border border-white/5 bg-zinc-900/60 px-5 py-4 text-center backdrop-blur-sm transition-all duration-300 ${scoreLevelClass}`}
                >
                  <span className="text-[11px] tracking-[0.22em] text-zinc-300 uppercase sm:text-xs">
                    Score del grupo
                  </span>
                  <div className="flex items-center gap-3">
                    <span className="text-4xl font-semibold text-white sm:text-5xl">
                      {groupScore.toFixed(2)}
                    </span>
                    {pillLabel && (
                      <span
                        className={`rounded-full px-3 py-1 text-xs font-semibold uppercase tracking-wide ${labelToneClass(
                          pillLabel,
                        )}`}
                      >
                        {pillLabel}
                      </span>
                    )}
                  </div>
                </div>
              )}
              {!loadingScore && !errorScore && groupScore === null && (
                <p className="text-sm text-white/70">
                  {canCalculateGroup
                    ? "Presioná CALCULAR GRUPO para ver un score aquí."
                    : "Seleccioná al menos 2 marcas para habilitar el cálculo."}
                </p>
              )}
            </div>
            <FuturisticDonut segments={segments} />
          </div>
        </div>

        <div className="rounded-2xl border border-dashed border-white/20 bg-white/5 p-5 text-sm text-white/80">
          {selectedNames.length ? (
            <>
              Marcas seleccionadas: {selectedNames.join(", ")}.
            </>
          ) : (
            <>Marcas seleccionadas: ninguna.</>
          )}
        </div>

        {pairs.length > 0 && <CompatibilityPanel pairs={pairs} />}
      </main>
    </div>
  );
}
