"use client";

export type Segment = { label: string; value: number };

type FuturisticDonutProps = {
  segments: Segment[];
};

const COLORS = [
  "#29A9FF", // Quantum Blue
  "#6C5BFF", // Fusion Violet
  "#38FFD9", // Aqua Circuit
  "#FF8F3F", // Thermal Orange
  "#6FFFA3", // Reactor Green
];

const SIZE = 360;
const CX = SIZE / 2;
const CY = SIZE / 2;
const RADIUS = 120;
const STROKE_WIDTH = 40;
const INNER_GLOW_RADIUS = 80;
const GAP_RATIO = 0.015;

export default function FuturisticDonut({ segments }: FuturisticDonutProps) {
  const normalizedSegments = segments.map((segment) => ({
    label: segment.label,
    value: Math.max(0, segment.value || 0),
  }));

  const total = normalizedSegments.reduce(
    (sum, segment) => sum + segment.value,
    0,
  );

  if (!total) {
    return (
      <div className="flex h-full flex-col items-center justify-center rounded-3xl border border-white/10 bg-black/50 p-6 text-center text-sm text-white/60">
        Asigná segundos a las marcas para ver el gráfico
      </div>
    );
  }

  const filteredSegments = normalizedSegments.filter(
    (segment) => segment.value > 0,
  );

  const circumference = 2 * Math.PI * RADIUS;
  const gapLength = circumference * GAP_RATIO;

  let currentOffset = 0;
  const arcSegments = filteredSegments
    .map((segment, index) => {
      const ratio = segment.value / total;
      const rawLength = circumference * ratio;
      const segmentLength = Math.max(0, rawLength - gapLength);

      if (segmentLength <= 0) return null;

      const config = {
        gradientId: `segment-gradient-${index}`,
        color: COLORS[index % COLORS.length],
        length: segmentLength,
        offset: currentOffset,
      };

      currentOffset += segmentLength + gapLength;
      return config;
    })
    .filter(
      (
        entry,
      ): entry is {
        gradientId: string;
        color: string;
        length: number;
        offset: number;
      } => Boolean(entry),
    );

  const LEGEND_ITEMS = filteredSegments.map((segment, index) => ({
    ...segment,
    color: COLORS[index % COLORS.length],
  }));

  return (
    <div className="rounded-3xl border border-white/10 bg-gradient-to-b from-black/70 to-zinc-900/40 p-6 shadow-[0_30px_90px_rgba(0,0,0,0.65)]">
      <div className="relative mx-auto flex h-[360px] w-[360px] items-center justify-center">
        <svg
          width={SIZE}
          height={SIZE}
          viewBox={`0 0 ${SIZE} ${SIZE}`}
          className="drop-shadow-[0_0_35px_rgba(0,0,0,0.9)]"
        >
          <defs>
            {/* Luz naranja en el centro */}
            <radialGradient id="innerGlow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="rgba(255,122,26,1)" />
              <stop offset="40%" stopColor="rgba(255,122,26,0.35)" />
              <stop offset="100%" stopColor="rgba(0,0,0,0)" />
            </radialGradient>

            {/* Glow fuerte para los segmentos (más blur y brillo) */}
            <filter id="arcGlow" x="-50%" y="-50%" width="200%" height="200%">
              {/* blur grande */}
              <feGaussianBlur stdDeviation="5" result="blur" />
              {/* mezcla el blur con el trazo original para que brille */}
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>

            {/* Gradientes de cada segmento con efecto medio transparente */}
            {arcSegments.map((segment) => (
              <linearGradient
                key={segment.gradientId}
                id={segment.gradientId}
                x1="0%"
                y1="0%"
                x2="100%"
                y2="100%"
              >
                <stop
                  offset="0%"
                  stopColor={segment.color}
                  stopOpacity={0.95}
                />
                <stop
                  offset="100%"
                  stopColor={segment.color}
                  stopOpacity={0.4}
                />
              </linearGradient>
            ))}
          </defs>

          {/* fondo del donut */}
          <circle cx={CX} cy={CY} r={RADIUS + STROKE_WIDTH / 2} fill="#050509" />

          {/* aro principal girando — SIN aro violeta extra */}
          <g
            transform={`rotate(-90 ${CX} ${CY})`}
            className="origin-center animate-spin-slow"
          >
            {[...arcSegments].reverse().map((segment) => (
              <circle
                key={segment.gradientId}
                cx={CX}
                cy={CY}
                r={RADIUS}
                fill="none"
                stroke={`url(#${segment.gradientId})`}
                strokeWidth={STROKE_WIDTH}
                strokeLinecap="butt"
                strokeDasharray={`${segment.length} ${circumference}`}
                strokeDashoffset={-segment.offset}
                filter="url(#arcGlow)" // más brillo y blur
              />
            ))}
          </g>

          {/* círculo interior oscuro + glow naranja */}
          <circle cx={CX} cy={CY} r={INNER_GLOW_RADIUS + 18} fill="#050509" />
          <circle cx={CX} cy={CY} r={INNER_GLOW_RADIUS} fill="url(#innerGlow)" />

          {/* texto central CO / FRAME en blanco */}
          <text
            x={CX}
            y={CY - 2}
            textAnchor="middle"
            fill="#FFFFFF"
            fontSize="40"
            fontWeight="800"
            letterSpacing="3"
            style={{ textTransform: "uppercase" }}
            className="font-joyride"
          >
            CO
          </text>
          <text
            x={CX}
            y={CY + 26}
            textAnchor="middle"
            fill="#FFFFFF"
            fontSize="14"
            fontWeight="700"
            letterSpacing="8"
            style={{ textTransform: "uppercase" }}
            className="font-joyride"
          >
            FRAME
          </text>
        </svg>
      </div>

      <div className="mt-4 space-y-2 text-sm">
        {LEGEND_ITEMS.map((segment, index) => (
          <div
            key={`legend-${index}`}
            className="flex items-center justify-between gap-3"
          >
            <div className="flex items-center gap-2">
              <span
                className="h-3 w-3 rounded-full"
                style={{ backgroundColor: segment.color }}
              />
              <span className="truncate text-zinc-200">{segment.label}</span>
            </div>
            <span className="text-zinc-400">
              {segment.value}s · {((segment.value / total) * 100).toFixed(1)}%
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
